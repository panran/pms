package pms.wms.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import jaguar.jsonapi.test.activerecord.ActiveRecordTestSupport;

import pms.wms.resource.EmployeeResource;

public class EmployeeServiceTest extends ActiveRecordTestSupport {
    private EmployeeService subject = new DefaultEmployeeService();

    @Test
    public void testCreate() {
        EmployeeResource resource = new EmployeeResource();
        resource.setName("towerhe");
        resource.setCode("007");

        EmployeeResource created = subject.create(resource);
        assertNotNull(created.getId());
    }

}
