package pms.wms.resource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.github.jasminb.jsonapi.DeserializationFeature;
import com.github.jasminb.jsonapi.JSONAPIDocument;
import com.github.jasminb.jsonapi.JSONAPISpecConstants;
import com.github.jasminb.jsonapi.Link;
import com.github.jasminb.jsonapi.Links;
import com.github.jasminb.jsonapi.ResourceConverter;
import com.github.jasminb.jsonapi.SerializationFeature;
import com.github.jasminb.jsonapi.exceptions.DocumentSerializationException;

public class CollectionSerializationTest {
    private JSONAPIDocument<List<EmployeeResource>> document;

    @Before
    public void setUp() {
        List<EmployeeResource> employees = new ArrayList<>();

        EmployeeResource employee = new EmployeeResource();
        employee.setName("Tower He");
        employee.setCode("007");

        employees.add(employee);

        document = new JSONAPIDocument<List<EmployeeResource>>(employees);

        Map<String, Object> meta = new HashMap<>();
        meta.put("total", 1);
        meta.put("total-page", 1);
        document.setMeta(meta);

        Map<String, Link> linkMap = new HashMap<>();
        linkMap.put(JSONAPISpecConstants.SELF, new Link(
                "http://localhost/employees?page[number]=1&page[size]=20"));
        linkMap.put(JSONAPISpecConstants.FIRST, new Link(
                "http://localhost/employees?page[number]=1&page[size]=20"));
        linkMap.put(JSONAPISpecConstants.LAST, new Link(
                "http://localhost/employees?page[number]=1&page[size]=20"));
        Links links = new Links(linkMap);

        document.setLinks(links);
    }

    @Test
    @Ignore
    public void testSerialize() throws DocumentSerializationException {
        ResourceConverter converter = new ResourceConverter(
                EmployeeResource.class);
        converter.disableDeserializationOption(
                DeserializationFeature.REQUIRE_RESOURCE_ID);
        converter.enableSerializationOption(SerializationFeature.INCLUDE_META);
        converter.enableSerializationOption(SerializationFeature.INCLUDE_LINKS);
        System.out.println(
                new String(converter.writeDocumentCollection(document)));
    }
}
