package pms.wms.integration.employee;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

import jaguar.jsonapi.test.integration.UpdateResourceTest;

import pms.wms.ApplicationModule;
import pms.wms.Application;
import pms.wms.activerecord.Employee;

import com.google.inject.Module;

import io.restassured.response.ValidatableResponse;

public class UpdateTest
        extends UpdateResourceTest<Employee, Application> {

    @Override
    protected void doValidate(ValidatableResponse response) {
        response.body("data.type", equalTo("employees"))
                .body("data.id", equalTo("1"))
                .body("data.attributes.name", equalTo("Jasmin"))
                .body("data.attributes.code", equalTo("001"))
                .body("data.attributes.created-at", notNullValue())
                .body("data.attributes.updated-at", notNullValue());
    }

    @Override
    protected Module[] getModules() {
        return new Module[] { new ApplicationModule("test") };
    }
}
