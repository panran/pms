package pms.wms.activerecord;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Locale;

import org.junit.Test;

import jaguar.jsonapi.test.activerecord.ActiveRecordTestSupport;

public class EmployeeTest extends ActiveRecordTestSupport {

    public Employee subject;

    @Test
    public void testValidation() {
        subject = new Employee();

        assertFalse(subject.isValid());
        assertTrue(subject.errors().containsKey("name"));
        assertTrue(subject.errors().containsKey("code"));
        assertEquals("不能为空",
                subject.errors(new Locale("zh", "CN")).get("name"));
        assertEquals("不能为空",
                subject.errors(new Locale("zh", "CN")).get("code"));

        subject.set("name", "towerhe");

        assertFalse(subject.isValid());
        assertFalse(subject.errors().containsKey("name"));
        assertTrue(subject.errors().containsKey("code"));
        assertEquals("不能为空",
                subject.errors(new Locale("zh", "CN")).get("code"));

        subject.set("code", "007");
        assertTrue(subject.isValid());

        Employee.createIt("name", "James Bond", "code", "007");

        assertFalse(subject.isValid());
        assertEquals("必须唯一",
                subject.errors(new Locale("zh", "CN")).get("code"));
    }

}
