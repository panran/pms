package pms.wms.integration;

import org.junit.Test;

import jaguar.jsonapi.test.integration.IntegrationTestSupport;

import pms.wms.Application;
import pms.wms.ApplicationModule;

import com.google.inject.Module;

public class ExceptionTest extends IntegrationTestSupport<Application> {

    @Test
    public void testAuthenticationException() {
        validateApi((spec) -> {
            spec.when()
                    .get(BASE_URL
                            + "/api/v1/exceptions/authentication_exception")
                    .then().statusCode(401);
        });
    }

    @Override
    protected Module[] getModules() {
        return new Module[] { new ApplicationModule("test") };
    }
}
