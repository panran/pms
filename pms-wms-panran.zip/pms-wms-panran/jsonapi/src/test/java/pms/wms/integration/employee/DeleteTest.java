package pms.wms.integration.employee;

import jaguar.jsonapi.test.integration.DeleteResourceTest;

import pms.wms.Application;
import pms.wms.ApplicationModule;
import pms.wms.activerecord.Employee;

import com.google.inject.Module;

public class DeleteTest
        extends DeleteResourceTest<Employee, Application> {

    @Override
    protected Module[] getModules() {
        return new Module[] { new ApplicationModule("test") };
    }
}
