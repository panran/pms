package pms.wms.activerecord;

import jaguar.jsonapi.orm.model.ActiveRecord;

public class Address extends ActiveRecord {
    static {
        validatePresenceOf("country", "province", "city", "county",
                "street_address").message("value.missing");
    }
}
