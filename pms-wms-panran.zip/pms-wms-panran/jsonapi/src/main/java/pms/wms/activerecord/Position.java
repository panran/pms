package pms.wms.activerecord;

import jaguar.jsonapi.orm.model.ActiveRecord;

public class Position extends ActiveRecord {
    static {
        validatePresenceOf("longitude", "latitude").message("value.missing");
    }
}
