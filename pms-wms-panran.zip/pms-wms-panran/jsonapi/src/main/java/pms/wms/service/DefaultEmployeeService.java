package pms.wms.service;

import jaguar.jsonapi.service.AbstractDbResourceService;

import pms.wms.activerecord.Employee;
import pms.wms.resource.EmployeeResource;

public class DefaultEmployeeService
        extends AbstractDbResourceService<EmployeeResource, Employee>
        implements EmployeeService {

}
