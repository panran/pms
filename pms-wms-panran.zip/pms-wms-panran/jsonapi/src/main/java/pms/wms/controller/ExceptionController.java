package pms.wms.controller;

import jaguar.jsonapi.annotation.GET;
import jaguar.jsonapi.controller.Controller;

import org.apache.shiro.authc.AuthenticationException;

public class ExceptionController extends Controller {
    @GET("exceptions/authentication_exception")
    public void throwAuthenticationException() {
        throw new AuthenticationException("Just for testing");
    }
}
