package pms.wms.activerecord;

import org.javalite.activejdbc.annotations.BelongsTo;
import org.javalite.activejdbc.annotations.BelongsToParents;

import jaguar.jsonapi.orm.model.ActiveRecord;

@BelongsToParents({
        @BelongsTo(foreignKeyName = "parent_id", parent = Branch.class),
        @BelongsTo(foreignKeyName = "manager_id", parent = Employee.class),
        @BelongsTo(foreignKeyName = "address_id", parent = Address.class) })
public class Branch extends ActiveRecord {
}
