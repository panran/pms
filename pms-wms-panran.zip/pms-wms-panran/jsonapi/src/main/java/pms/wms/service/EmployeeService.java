package pms.wms.service;

import jaguar.jsonapi.service.DbResourceService;

import pms.wms.activerecord.Employee;
import pms.wms.resource.EmployeeResource;

import com.google.inject.ImplementedBy;

@ImplementedBy(DefaultEmployeeService.class)
public interface EmployeeService
        extends DbResourceService<EmployeeResource, Employee> {

}
