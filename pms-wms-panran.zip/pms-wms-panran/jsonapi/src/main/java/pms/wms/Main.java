package pms.wms;

import jaguar.jsonapi.JsonapiApplication;
import jaguar.jsonapi.Standalone;

import com.google.inject.Guice;
import com.google.inject.Injector;

public class Main extends Standalone {
    public static void main(String[] args) {
        String env = JsonapiApplication.env();
        Injector injector = Guice.createInjector(new ApplicationModule(env));
        injector.getInstance(Main.class).run();
    }
}
