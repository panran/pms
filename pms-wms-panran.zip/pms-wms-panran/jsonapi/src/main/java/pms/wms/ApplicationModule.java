package pms.wms;

import jaguar.jsonapi.JsonapiApplication;
import jaguar.jsonapi.JsonapiApplicationModule;
import jaguar.jsonapi.resource.Resource;

import pms.wms.resource.EmployeeResource;

import java.util.Arrays;
import java.util.List;

public class ApplicationModule extends JsonapiApplicationModule {

    public ApplicationModule(String env) {
        super(env);
    }

    @Override
    protected Class<? extends JsonapiApplication> getApplicationClass() {
        return Application.class;
    }

    @Override
    protected List<Object> getReflectionParams() {
        return Arrays.asList("pms.wms");
    }

    @SuppressWarnings("unchecked")
    @Override
    protected Class<? extends Resource>[] getResourceClasses() {
        return new Class[] { EmployeeResource.class };
    }

}
