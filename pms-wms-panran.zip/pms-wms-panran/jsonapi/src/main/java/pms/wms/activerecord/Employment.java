package pms.wms.activerecord;

import jaguar.jsonapi.orm.model.ActiveRecord;

public class Employment extends ActiveRecord {
    static {
        validatePresenceOf("branch_id", "employee_id").message("value.missing");
    }
}
