package pms.wms;

import jaguar.jsonapi.ActiveJdbcJsonapiApplication;

import com.google.inject.Module;
import com.google.inject.Singleton;

@Singleton
public class Application extends ActiveJdbcJsonapiApplication {

    @Override
    public String getName() {
        return "pms-wms";
    }

    @Override
    public void destroy() {
        getLogger().info("Destroy pms-wms");
    }

    @Override
    public Module[] modules() {
        return new Module[] { new ApplicationModule("development") };
    }

}
