package pms.wms.controller;

import jaguar.jsonapi.annotation.ResourceService;
import jaguar.jsonapi.controller.ResourceController;

import pms.wms.activerecord.Employee;
import pms.wms.resource.EmployeeResource;
import pms.wms.service.EmployeeService;

@ResourceService(EmployeeService.class)
public class EmployeeController
        extends ResourceController<EmployeeResource, Employee> {

}
