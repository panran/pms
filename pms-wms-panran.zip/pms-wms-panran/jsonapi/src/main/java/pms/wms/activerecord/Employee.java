package pms.wms.activerecord;

import jaguar.jsonapi.orm.model.ActiveRecord;
import jaguar.jsonapi.orm.validator.UniquenessValidator;

public class Employee extends ActiveRecord {
    static {
        validatePresenceOf("name", "code").message("value.missing");
        validateWith(new UniquenessValidator("code"))
                .message("value.duplicated");
    }
}
