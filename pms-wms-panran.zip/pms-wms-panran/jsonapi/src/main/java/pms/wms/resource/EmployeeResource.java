package pms.wms.resource;

import jaguar.jsonapi.resource.Resource;

import com.github.jasminb.jsonapi.annotations.Type;

@Type("employees")
public class EmployeeResource extends Resource {
    private String name;
    private String code;
    private String gender;
    private String mobile;
    private String title;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}
