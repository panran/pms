CREATE TABLE branches (
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  parent_id INT(11),
  address_id INT(11),
  manager_id INT(11),
  code VARCHAR(50),
  name VARCHAR(255),
  telephone VARCHAR(20),
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
