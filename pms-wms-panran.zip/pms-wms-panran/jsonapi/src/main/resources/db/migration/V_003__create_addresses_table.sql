CREATE TABLE addresses (
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  position_id INT(11),
  country VARCHAR(20),
  province VARCHAR(20),
  city VARCHAR(50),
  county VARCHAR(50),
  town VARCHAR(50),
  street_address VARCHAR(255),
  secondary_address VARCHAR(255),
  postcode VARCHAR(6),
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
