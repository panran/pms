CREATE TABLE employees (
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(32),
  name VARCHAR(50),
  gender VARCHAR(2),
  title VARCHAR(20),
  mobile VARCHAR(20),
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
