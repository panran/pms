CREATE TABLE object_attributes (
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  object_type VARCHAR(100) NOT NULL,
  attribute_type VARCHAR(100) NOT NULL,
  attribute_name VARCHAR(100) NOT NULL,
  attribute_value TEXT,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
