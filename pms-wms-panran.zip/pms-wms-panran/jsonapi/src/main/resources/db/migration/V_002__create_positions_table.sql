CREATE TABLE positions (
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  longitude DECIMAL(9,6),
  latitude DECIMAL(9,6),
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
