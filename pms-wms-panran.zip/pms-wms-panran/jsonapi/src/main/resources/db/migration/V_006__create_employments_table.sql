CREATE TABLE employments (
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  branch_id INT(11),
  employee_id INT(11),
  signed_on DATE,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
