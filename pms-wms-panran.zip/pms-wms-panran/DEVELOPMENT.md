## 开发手册

### 搭建开发环境

#### Vagrant环境

TODO

#### Java环境

TODO

#### Python环境

TODO

#### Ember环境

TODO

#### Ruby环境（可选）

TODO

### 安装`jaguar-jsonapi`

`jaguar-jsonapi`是本项目依赖的有懋光信安研发的基础库项目，目前处于闭源状态，且没有搭建内部`Maven`仓库，因此需要手动进行安装。安装方法如下：

  ```
  # 从源代码库中迁出`jaguar-jsonapi`项目。如果没有权限，请于管理员联系
  $ git clone git@gitlab.com:maoguang-jaguar/jaguar-jsonapi.git

  # 将`jsonapi`安装到本地`Maven`仓库
  $ cd /path/to/jaguar-jsonapi
  $ mvn install
  ```

### 打包`pms-wms`

  ```
  # 从源代码库中迁出`pms-wms`项目。如果没有权限，请于管理员联系
  $ git clone git@gitlab.com:maoguang-java/pms-wms.git

  # 制作安装包
  $ cd /path/to/pms-wms
  $ fab package
  ```

### 安装`pms-wms`

首先，请确认您要部署的服务器上正确安装了`Java`环境（版本要求JDK1.8+），如果没有安装，可以参照`Java`环境安装一节进行安装。

  ```
  # 复制安装包到指定服务器
  $ scp ./releases/pms-wms-standalone-0.1.0-SNAPSHOT-bin.tar.gz ${user}@${server.ip}:/path/to/deploy

  # 登录远程服务器并安装
  $ ssh ${user}@${server.ip}
  $ cd /path/to/deploy
  $ tar xvf pms-wms-standalone-0.1.0-SNAPSHOT-bin.tar.gz
  $ cd pms-wms-standalone-0.1.0-SNAPSHOT
  $ ./bin/setup.sh

  # 启动服务，服务启动后通过浏览器访问：http://${server.ip}:22501，即可登录系统
  $ /etc/init.d/pms-wms start

  # 停止服务
  $ /etc/init.d/pms-wms stop
  ```
