# -*- condig:utf-8 -*-
from dotenv import load_dotenv, find_dotenv
load_dotenv(find_dotenv())

from jaguar.tasks import *

env.hosts = os.environ.get('SERVERS').split(';')
env.user  = os.environ.get('DEPLOYER')
