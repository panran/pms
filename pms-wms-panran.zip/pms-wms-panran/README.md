## pms-wms

### 开发指南

#### 搭建开发环境

项目开发中使用Maven作为构建工具，因此需要在开发机上事先安装配置好Maven。详见：http://maven.apache.org。

首先，从源码库中签出项目源代码：

  ```bash
  git clone git@gitlab.com:maoguang-java/pms-wms.git
  ```

然后使用你最爱的IDE，比如eclipse，将项目导入便可进行开发。注意：eclipse需要安装m2e插件，以便可以使用Maven。

生成Eclipse项目相关文件：

  ```bash
  mvn eclipse:eclipse
  ```

*注意：* 项目依赖`jaguar-jsonapi`，构建项目，需要在本地Maven库中安装依赖项目的相关包。安装步骤如下：

1. 从源代码库中签出依赖项目。

  ```bash
  git clone git@gitlab.com:maoguang-jaguar/jaguar-jsonapi.git
  ```

2. 安装依赖项目到本地库。

  ```bash
  cd /path/to/jaguar-jsonapi
  mvn install
  ```

#### 项目说明

1. jsonapi

RESTful Web Services API

2. web

Ember前端应用

3. war

用于将项目打包成可以部署在Web容器（如tomcat）中的war包。

4. standalone

用于将项目打包成可以独立运行的包。

#### 开发说明

1. web

进入`web/src/main/ember`来进行开发，请查看 [http://ember-cli.com](http://ember-cli.com) 获取帮助。

打包方法：

  ```
  cd web/src/main/ember/pms-wms
  ember build -o ../resources/public -prod
  cd ..
  mvn package
  ```

#### 单元测试

运行单元测试只需在项目目录下，执行：

  ```bash
  mvn test
  ```
