import {
  validatePresence,
  validateFormat
} from 'ember-changeset-validations/validators';

export default {
  name: [
    validatePresence({ presence: true, message: '不能为空' })
  ],
  weight: [

    validateFormat({ regex: /^\d{0,10}$/, message: '只能是数字，且长度不超过10' })
  ],

};

