import Ember from 'ember';
import NewControllerMixin from '../../mixins/controller/new';

export default Ember.Controller.extend(NewControllerMixin, {

});
