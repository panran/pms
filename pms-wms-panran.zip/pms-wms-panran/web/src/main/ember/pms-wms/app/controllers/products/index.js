import Ember from 'ember';
import IndexControllerMixin from '../../mixins/controller/index';

export default Ember.Controller.extend(IndexControllerMixin, {

  brands:Ember.computed(function() {
    return this.store.findAll('brand');
  }),
  queryParams: [{
    currentPage: 'page',
    pageSize: 'limit',
    name: 'name',
    barCode: 'barCode',
    brandId: 'brandId'
  }],
  name: null,
  barCode: null,
  brandId:null,
  currentPage: 1,

  query: Ember.Object.create({
    'name': null,
    'barCode': null,
    'brandId': null
  }),

  actions: {
    search(query) {
      this.set('currentPage', 1);

      if(!Ember.isEmpty(query.get('name'))) {
        this.set('name', query.get('name'));
      } else {
        this.set('name', null);
      }
      if(!Ember.isEmpty(query.get('barCode'))) {
        this.set('barCode', query.get('barCode'));
      } else {
        this.set('barCode', null);
      }
      if(Ember.isPresent(query.get('brand.id'))) {
        this.set('brandId', query.get('brand.id'));
      } else {
        this.set('brandId', null);
      }

      return Ember.RSVP.Promise.resolve();
    }
  }
});
