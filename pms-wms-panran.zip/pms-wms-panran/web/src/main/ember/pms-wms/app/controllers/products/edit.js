import Ember from 'ember';
import EditControllerMixin from '../../mixins/controller/edit';
import ProductValidations from '../../validations/product';
const {
  set,
  get,
  $,
  inject: { service }
} = Ember;
export default Ember.Controller.extend(EditControllerMixin, {
  ProductValidations,
   ajax: service(),
  description: '',
  contentHeight: 300,
  editingDisabled: false,
  toolbarOptions: {
    style: false,
    insert: {
      picture: true
    },
    help: true
  },
  callbackOptions: Ember.computed(function() {
    return {
      onImageUpload: files => {
        let ajax = this.get('ajax');
        Array.from(files).forEach(file => {
          let formData = new FormData();
          formData.set('file', file);
          ajax.post('/api/v1/uploaded-files', {
            data: formData,
            processData: false,
            contentType: false
          }).then(data => {
            $('#summernote').summernote('insertImage', get(data, 'data.attributes.file-path'));
          });
        });
        console.log(files);
      }
    }
  }),
  actions: {
    onContentChange(data) {
      set(this, 'model.description', data);
    },

    rerenderCheck(data) {
      set(this, 'model.description', data);
    }
  }
});
