import Ember from 'ember';

export default Ember.Service.extend({
  transitionTo: function(...args) {
    this.trigger('transitionTo', args);
  }
});
