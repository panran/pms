import Ember from 'ember';

import EditMixin from 'ember-inspinia/mixins/controller/edit';
// import AuthenticatedMixin from './authenticated';

export default Ember.Mixin.create(EditMixin);
