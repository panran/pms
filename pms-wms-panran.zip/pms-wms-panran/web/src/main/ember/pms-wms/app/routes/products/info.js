import Ember from 'ember';
import EditRouteMixin from 'ember-inspinia/mixins/route/model/edit';
export default Ember.Route.extend(EditRouteMixin,{
      modelName: 'product'
});
