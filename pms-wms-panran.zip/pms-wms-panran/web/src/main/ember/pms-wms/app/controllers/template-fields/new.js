import Ember from 'ember';
import NewControllerMixin from '../../mixins/controller/new';
import TemplateFieldValidations from '../../validations/template-field';

export default Ember.Controller.extend(NewControllerMixin, {
  TemplateFieldValidations,
  specifications: Ember.computed( function() {
    return this.get('store').findAll('specification-template');
  }),
  templateFields: Ember.computed( function() {
    return this.get('store').findAll('template-field');
  }),
});