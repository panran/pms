import DS from 'ember-data';

export default DS.Model.extend({
  name: DS.attr(),
  barCode: DS.attr(),
  origin: DS.attr(),
  weight: DS.attr(),
  description: DS.attr(),
  brand: DS.belongsTo('brand')
});
