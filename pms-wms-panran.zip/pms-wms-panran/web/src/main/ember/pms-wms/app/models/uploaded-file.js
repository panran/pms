import DS from 'ember-data';

export default DS.Model.extend({
  fileName: DS.attr(),
  filePath: DS.attr(),
  fileSize: DS.attr()
});