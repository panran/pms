import Ember from 'ember';

import NewMixin from 'ember-inspinia/mixins/controller/new';
//import AuthenticatedMixin from './authenticated';

export default Ember.Mixin.create(NewMixin);
