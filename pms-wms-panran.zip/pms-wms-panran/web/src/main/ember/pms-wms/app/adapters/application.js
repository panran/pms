import DS from 'ember-data';
import Ember from 'ember';

const { JSONAPIAdapter } = DS;
const {
  inject: { service }
} = Ember;

export default JSONAPIAdapter.extend({
  namespace: 'api/v1',
  routing: service(),

  handleResponse(status) {
    if (status === 403 && this.get('session.isAuthenticated')) {
      this.get('session').invalidate();
    }
    if (status === 503) {
      this.get('routing').transitionTo('503', { queryParams: { from: window.location.hash }});
    }
    return this._super(...arguments);
  }
});
