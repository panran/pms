import Ember from 'ember';
import IndexControllerMixin from '../../mixins/controller/index';

export default Ember.Controller.extend(IndexControllerMixin, {
  queryParams: [{
    currentPage: 'page',
    pageSize: 'limit',
    name: 'name',
    productId: 'productId'

  }],
  name: null,
  productId:null,
  currentPage: 1, 

  query: Ember.Object.create({
    'name': null,
    'productId': null
  }),

  products: Ember.computed(function() {
    return this.store.findAll('product');
  }),

  actions: {
    search(query) {
      this.set('currentPage', 1);

      if(!Ember.isEmpty(query.get('name'))) {
        this.set('name', query.get('name'));
      } else {
        this.set('name', null);
      }
      if(Ember.isPresent(query.get('product.id'))) {
        this.set('productId', query.get('product.id'));
      } else {
        this.set('productId', null);
      }

      return Ember.RSVP.Promise.resolve();
    },

    new(){
     
      this.store.createRecord('template-field-value',{});
    }
  }
});
