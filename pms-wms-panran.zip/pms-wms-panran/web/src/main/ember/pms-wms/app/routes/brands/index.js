import Ember from 'ember';
import IndexRouteMixin from 'ember-inspinia/mixins/route/model/index';

export default Ember.Route.extend(IndexRouteMixin, {
  modelName: 'brand',

  queryParams: {
    name: { refreshModel: true },
    brandLogoId: { refreshModel: true },
    currentPage: { refreshModel: true },
    pageSize: { refreshModel: true }
  },

  model(params) {
    return this.store.query('brand', this._buildQuery(params));
  },

  resetController(controller, isExiting) {
    if (isExiting) {
      controller.set('name', null);
      controller.set('brandLogoId', null);
    }
  },

  setupController(controller, model) {
    this._super(...arguments);

    controller.set('total', model.get('meta.total'));
    controller.set('model', model);
  },

  _buildQuery(params) {
    let query = {
      'page[number]': params.currentPage,
      'page[size]': params.pageSize,
      'sort': '-id',
      'include': 'brandLogo',
    };

    if(!Ember.isEmpty(params.name)) {
      query['filter[name_cont]'] = params.name;
    }
   if(!Ember.isEmpty(params.brandLogoId)) {
      query['filter[brand_logo_id_cont]'] = params.brandLogoId;
    }
    return query;
  }

});
