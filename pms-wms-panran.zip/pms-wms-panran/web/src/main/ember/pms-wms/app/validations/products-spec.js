import {
  validatePresence
} from 'ember-changeset-validations/validators';

export default {
  name: [
    validatePresence({ presence: true, message: '不能为空' })
  ]
};
