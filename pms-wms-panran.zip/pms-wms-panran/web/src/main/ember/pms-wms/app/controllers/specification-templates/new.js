import Ember from 'ember';
import NewControllerMixin from '../../mixins/controller/new';
import SpecificationTemplateValidations from '../../validations/specification-template';

export default Ember.Controller.extend(NewControllerMixin, {
  SpecificationTemplateValidations,
});