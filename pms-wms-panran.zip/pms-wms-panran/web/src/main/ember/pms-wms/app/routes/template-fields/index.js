import Ember from 'ember';

import IndexRouteMixin from 'ember-inspinia/mixins/route/model/index';

export default Ember.Route.extend(IndexRouteMixin, {
  modelName: 'template-field',

  queryParams: {
    name: { refreshModel: true },
    specificationTemplateId: { refreshModel: true },
    currentPage: { refreshModel: true },
    pageSize: { refreshModel: true }
  },

  model(params) {
    return this.store.query('template-field', this._buildQuery(params));
  },

  resetController(controller, isExiting) {
    if (isExiting) {
      controller.set('name', null);
      controller.set('specificationTemplateId', null);
    }
  },

  setupController(controller, model) {
    this._super(...arguments);

    controller.set('total', model.get('meta.total'));
    controller.set('model', model);
  },

  _buildQuery(params) {
    let query = {
      'page[number]': params.currentPage,
      'page[size]': params.pageSize,
      'sort': '-id',
      'include': 'specificationTemplate',
    };

    if(!Ember.isEmpty(params.name)) {
      query['filter[name_cont]'] = params.name;
    }
   if(!Ember.isEmpty(params.specificationTemplateId)) {
      query['filter[specification_template_id_cont]'] = params. specificationTemplateId;
    }
    return query;
  }

});