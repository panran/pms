import Ember from 'ember';
import IndexRouteMixin from 'ember-inspinia/mixins/route/model/index';

export default Ember.Route.extend(IndexRouteMixin, {

  breadCrumb: Ember.computed(function() {
    return {
      title: this.get('i18n').t('titles.products')
    };
  }),
  modelName: 'product',
  queryParams: {
    name: { refreshModel: true },
    barCode: { refreshModel: true },
    brandId: {refreshModel: true },
    currentPage: { refreshModel: true },
    pageSize: { refreshModel: true }
  },

  model(params) {
    return this.store.query('product', this._buildQuery(params));
  },

  resetController(controller, isExiting) {
    if (isExiting) {
      controller.set('name', null);
      controller.set('barCode', null);
      controller.set('brandId', null);

    }
  },

  setupController(controller, model) {
    this._super(...arguments);
    controller.set('total', model.get('meta.total'));
    controller.set('model', model);
  },

  _buildQuery(params) {
    let query = {
       'include': 'brand',
      'page[number]': params.currentPage,
      'page[size]': params.pageSize,
      'sort': '-id'
    };

    if(!Ember.isEmpty(params.name)) {
      query['filter[name]'] = params.name;
    }
    if(!Ember.isEmpty(params.barCode)) {
      query['filter[bar_code]'] = params.barCode;
    }
    if(!Ember.isEmpty(params.brandId)) {
      query['filter[brand_id]'] = params.brandId;
    }

    return query;
  }

});
