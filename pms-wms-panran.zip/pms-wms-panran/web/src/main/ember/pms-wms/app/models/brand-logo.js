import DS from 'ember-data';

export default DS.Model.extend({
  filePath: DS.attr(),
  name: DS.attr(),
});
