import Ember from 'ember';

import IndexControllerMixin from '../../mixins/controller/index';

export default Ember.Controller.extend(IndexControllerMixin, {
  queryParams: [{
    currentPage: 'page',
    pageSize: 'limit',
    name: 'name',
    specificationTemplateId: 'specificationTemplateId' 
  }],
  name: null,
  specificationTemplateId: null,
  currentPage: 1,

  query: Ember.Object.create({
    'name': null,
    'specificationTemplateId': null
  }),

  specificatonTemplates: Ember.computed(function() {
    return this.store.findAll('specification-template');
  }),

  actions: {
    search(query) {
      this.set('currentPage', 1);

      if(!Ember.isEmpty(query.get('name'))) {
        this.set('name', query.get('name'));
      } else {
        this.set('name', null);
      }
      if(!Ember.isEmpty(query.get('specificationTemplate.id'))) {
        this.set('specificationTemplateId', query.get('specificationTemplate.id'));
      } else {
        this.set('specificationTemplateId', null);
      }
      return Ember.RSVP.Promise.resolve();
    }
  }
});