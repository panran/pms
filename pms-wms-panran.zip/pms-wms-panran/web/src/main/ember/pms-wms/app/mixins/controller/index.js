import Ember from 'ember';

import PageableMixin from 'ember-inspinia/mixins/controller/pageable';
//import AuthenticatedMixin from './authenticated';

export default Ember.Mixin.create(PageableMixin);
