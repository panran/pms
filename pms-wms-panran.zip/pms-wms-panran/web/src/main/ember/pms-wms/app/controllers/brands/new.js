import Ember from 'ember';
import NewControllerMixin from '../../mixins/controller/new';
import BrandValidations from '../../validations/brand';

export default Ember.Controller.extend(NewControllerMixin, {
  BrandValidations,
 brandLogos: Ember.computed( function() {
    return this.get('store').findAll('brand-logo');
  }),
});
