import Ember from 'ember';
import EditControllerMixin from '../../mixins/controller/edit';

export default Ember.Controller.extend(EditControllerMixin, {

});
