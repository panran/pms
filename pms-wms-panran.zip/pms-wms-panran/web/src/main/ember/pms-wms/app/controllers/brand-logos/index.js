import Ember from 'ember';
import IndexControllerMixin from '../../mixins/controller/index';
export default Ember.Controller.extend(IndexControllerMixin,{
queryParams: [{
    currentPage: 'page',
    pageSize: 'limit',
    name: 'name'
  }],
  name: null,
  currentPage: 1,

  query: Ember.Object.create({
    'name': null
  }),

  actions: {
    search(query) {
      this.set('currentPage', 1);

      if(!Ember.isEmpty(query.get('name'))) {
        this.set('name', query.get('name'));
      } else {
        this.set('name', null);
      }

      return Ember.RSVP.Promise.resolve();
    }
  }
});
