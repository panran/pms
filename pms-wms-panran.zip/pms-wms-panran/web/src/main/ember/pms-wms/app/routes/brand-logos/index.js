import Ember from 'ember';
import IndexRouteMixin from 'ember-inspinia/mixins/route/model/index';

export default Ember.Route.extend(IndexRouteMixin,{
  modelName:'brand-logo'
});
