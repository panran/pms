import Ember from 'ember';


export default Ember.Controller.extend({
  config: Ember.inject.service(),

  footer: Ember.computed.alias('config.footer'),
  menu: Ember.computed.alias('config.menu')

});
