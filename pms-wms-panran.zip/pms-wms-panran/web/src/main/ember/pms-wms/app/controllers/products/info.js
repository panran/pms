import Ember from 'ember';
import EditControllerMixin from '../../mixins/controller/edit';
import ProductValidations from '../../validations/product';
export default Ember.Controller.extend(EditControllerMixin, {
  ProductValidations,
});
