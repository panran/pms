import Ember from 'ember';
import NewControllerMixin from '../../mixins/controller/new';
import ProductValidations from '../../validations/product';
const {
  set,
  get,
  $,
  inject: { service }
} = Ember;
export default Ember.Controller.extend(NewControllerMixin, {
  ProductValidations,

  ajax: service(),

  brands: Ember.computed( function() {
    return this.get('store').findAll('brand');
  }),

  description: '',
  contentHeight: 300,
  editingDisabled: false,
  toolbarOptions: {
    style: false,
    insert: {
      picture: true
    },
    help: true
  },
  callbackOptions: Ember.computed(function() {
    return {
      onImageUpload: files => {
        let ajax = this.get('ajax');
        Array.from(files).forEach(file => {
          let formData = new FormData();
          formData.set('file', file);
          ajax.post('/api/v1/uploaded-files', {
            data: formData,
            processData: false,
            contentType: false
          }).then(data => {
            $('#summernote').summernote('insertImage', get(data, 'data.attributes.file-path'));
               //  console.log(get(data, 'data.attributes.file-path'));
               console.log(data);

          });
        });

      }
    }
  }),
  actions: {
    onContentChange(data) {
      set(this, 'model.description', data);
    },

    rerenderCheck(data) {
      set(this, 'model.description', data);
    }
  }
});
