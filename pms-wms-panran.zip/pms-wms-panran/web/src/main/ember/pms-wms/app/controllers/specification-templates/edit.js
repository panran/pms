import Ember from 'ember';
import EditControllerMixin from '../../mixins/controller/edit';
import SpecificationTemplateValidations from '../../validations/specification-template';

export default Ember.Controller.extend(EditControllerMixin, {
  SpecificationTemplateValidations,

  fileds: Ember.computed(function() {
    return this.get('store').findAll('template-field');
  })
});