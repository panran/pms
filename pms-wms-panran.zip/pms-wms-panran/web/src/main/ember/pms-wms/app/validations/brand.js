import {
  validatePresence,validateLength
} from 'ember-changeset-validations/validators';

export default {
  name: [
    validatePresence({ presence: true, message: '不能为空' })
  ],
  description:validateLength({ max: 50,message:'最大长度不能超过50字' }),
};
