import Ember from 'ember';
import EditControllerMixin from '../../mixins/controller/edit';
import TemplateFieldValidations from '../../validations/template-field';

export default Ember.Controller.extend(EditControllerMixin, {
  TemplateFieldValidations,
  specifications: Ember.computed( function() {
    return this.get('store').findAll('specification-template');
  })
});

