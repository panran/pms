import Ember from 'ember';
import NewRouteMixin from 'ember-inspinia/mixins/route/model/new';

export default Ember.Route.extend(NewRouteMixin, {
    modelName: 'product'
});
