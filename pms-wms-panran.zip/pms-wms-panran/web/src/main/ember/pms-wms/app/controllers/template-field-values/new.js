import Ember from 'ember';
import NewControllerMixin from '../../mixins/controller/new';
import TemplateFieldValueValidations from '../../validations/template-field-value';

export default Ember.Controller.extend(NewControllerMixin, {
  TemplateFieldValueValidations,
  products: Ember.computed( function() {
    return this.get('store').findAll('product');
  }),
});