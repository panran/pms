import Ember from 'ember';
import isEnabled from 'ember-data/-private/features';

export default Ember.Mixin.create({
  ignoreFields: [],

  _checkKey(key) {
    return this.get('ignoreFields').indexOf(key) > -1;
  },

  serializeBelongsTo(snapshot, json, relationship) {
    var key = relationship.key;

    if (this._checkKey(key)) {
      this._super(snapshot, json, relationship);
      return;
    }

    if (this._canSerialize(key)) {
      var belongsTo = snapshot.belongsTo(key);
      if (belongsTo !== undefined) {

        json.relationships = json.relationships || {};

        var payloadKey = this._getMappedKey(key, snapshot.type);
        if (payloadKey === key) {
          payloadKey = this.keyForRelationship(key, 'belongsTo', 'serialize');
        }

        json.relationships[payloadKey] = this.serialize(belongsTo);
      }
    }
  },

  serializeHasMany(snapshot, json, relationship) {
    var key = relationship.key;

    if (this._checkKey(key)) {
      this._super(...arguments);
      return;
    }

    var shouldSerializeHasMany = '_shouldSerializeHasMany';
    if (isEnabled("ds-check-should-serialize-relationships")) {
      shouldSerializeHasMany = 'shouldSerializeHasMany';
    }

    if (this[shouldSerializeHasMany](snapshot, key, relationship)) {
      var hasMany = snapshot.hasMany(key);
      if (hasMany !== undefined) {

        json.relationships = json.relationships || {};

        var payloadKey = this._getMappedKey(key, snapshot.type);
        if (payloadKey === key && this.keyForRelationship) {
          payloadKey = this.keyForRelationship(key, 'hasMany', 'serialize');
        }

        let data = new Array(hasMany.length);

        for (let i = 0; i < hasMany.length; i++) {
          let item = hasMany[i];

          data[i] = this.serialize(item);
        }

        json.relationships[payloadKey] = data;
      }
    }
  }
});
