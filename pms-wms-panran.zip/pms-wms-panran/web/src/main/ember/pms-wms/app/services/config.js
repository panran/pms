import Ember from 'ember';

export default Ember.Service.extend({
  i18n: Ember.inject.service(),
  menu: Ember.computed(function() {
    let i18n = this.get('i18n');
    return Ember.A([{
      label: i18n.t('labels.menu.brand'),
      icon: 'fa fa-star-o',
      level: 'second',
      children: [
        {
        label: '图标管理',
        route: 'brand-logos.index',
      },{
        label: '品牌信息',
        route: 'brands.index',
      }]},{
      label: i18n.t('labels.menu.product'),
      icon: 'fa fa-cubes',
      route: 'products',
      children: []
     },{
      label: i18n.t('labels.menu.template-field-value'),
      icon: 'fa fa-glass',
      level: 'second',
      children: [
        {
        label: i18n.t('labels.menu.template-field-value.add'),
        route: 'template-field-values.new',
      },{
        label: i18n.t('labels.menu.template-field-value.search'),
        route: 'template-field-values.index',
      }]},{
      label: i18n.t('labels.menu.specification-template'),
      icon: 'fa fa-credit-card',
      level: 'second',
      children: [
       {
        label:i18n.t('labels.menu.specification-template.add'),
        route: 'specification-templates.new',
      },{
        label: i18n.t('labels.menu.specification-template.search'),
        route: 'specification-templates.index',
      }]},{
      label: i18n.t('labels.menu.template-field'),
      icon: 'fa fa-book',
      level: 'second',
      children: [
        {
        label: i18n.t('labels.menu.template-field.add'),
        route: 'template-fields.new',
      },{
        label: i18n.t('labels.menu.template-field.search'),
        route: 'template-fields.index',
      }]}
    ]);
  })
});
