import Ember from 'ember';
import NewRouteMixin from 'ember-inspinia/mixins/route/model/new';
export default Ember.Route.extend(NewRouteMixin,{
  modelName:'brand-logo',
  setupController: function(controller, model) {
    this._super(controller, model);

  controller.reopen({
    success: Ember.computed(function() {
     let model=this.get('model')
     return function(file,filePath)
     {
       model.set('filePath',Ember.get(JSON.parse(filePath),'data.attributes.file-path'));
       model.set('name',Ember.get(JSON.parse(filePath),'data.attributes.file-name'));
       console.log(filePath);
       console.log(model.filePath);
       console.log(model.name);
     }
  }),


  });
  }
});
