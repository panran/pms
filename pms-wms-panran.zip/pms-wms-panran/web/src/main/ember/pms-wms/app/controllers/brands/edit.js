import Ember from 'ember';
import EditControllerMixin from '../../mixins/controller/edit';
import BrandValidations from '../../validations/brand';

export default Ember.Controller.extend(EditControllerMixin, {
  BrandValidations,
  brandLogos: Ember.computed( function() {
    return this.get('store').findAll('brand-logo');
  }),
});
